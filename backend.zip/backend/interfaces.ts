export interface ErrorResponse {
    error: string;
}

export interface SuccessResponse {
    message: string;
}
